#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<stdio.h>
#include<dirent.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/types.h>
#include<errno.h>

int y;
void readres(int fd){
char p[4];
read(fd,p,4);
if(strncmp(p,"220",3)==0){
printf("220:Service ready for new user\n");
}
else if(strncmp(p,"226",3)==0){
printf("226:Logging in\n");
}
else if(strncmp(p,"530",3)==0){
printf("530:Logging failed\n");
exit(0);
}
else if(strncmp(p,"331",3)==0){
printf("331:User name ok,need password\n");
}
else if(strncmp(p,"332",3)==0){
printf("332:Need account for login\n");
}
else if(strncmp(p,"225",3)==0){
printf("225:Data connection open\n");
}
else if(strncmp(p,"250",3)==0){
printf("250:Command complete\n");
}
else if(strncmp(p,"221",3)==0){
printf("221:Goodbye\n");
}
else if(strncmp(p,"213",3)==0){
printf("213:Open the file\n");
y=213;
}
else if(strncmp(p,"450",3)==0){
printf("450:Can not open file\n");
y=450;
}

}

void login(int fd){
char user[30],pass[30];
readres(fd);
gets(user);
write(fd,user,sizeof(user));
readres(fd);
gets(pass);
write(fd,pass,sizeof(pass));
}

int dataconn(){
int fd;
struct sockaddr_in sock;
fd=socket(AF_INET,SOCK_STREAM,0);
bzero(&sock,sizeof(sock));
sock.sin_family=AF_INET;
sock.sin_port=htons(20);
sock.sin_addr.s_addr=inet_addr("127.0.0.1");
if(connect(fd,(struct sockaddr*)&sock,sizeof(sock))<0){
printf("%d",errno);
exit(0);
}
return fd;
}

void list(int fd,int datafd,char msg[]){
char buf[100];
memset(buf,0,100);
FILE* fp=fopen("ser.txt","w");
int n;
readres(fd);
if(y==450) return;
while(read(datafd,buf,100)){
int n=strlen(buf);
if(n==1) break;
printf("%d:%s",n,buf);
fwrite(buf,1,sizeof(buf),fp);
memset(buf,0,100);
}
fclose(fp);
readres(fd);
}

void retr(int fd,int datafd,char msg[]){
int n;
char buf[100];
readres(fd);
if(y==450) return;
while((n=read(datafd,buf,100))>0){
if(strncmp("END",buf,3)==0) break;
printf("%s",buf);
}
readres(fd);
}

void process(int fd){
readres(fd);
login(fd);
readres(fd);
int datafd=dataconn();
readres(fd);
char msg[30];
while(1){
gets(msg);
write(fd,msg,sizeof(msg));
if(strncmp(msg,"QUIT",4)==0){
readres(fd);
exit(0);
}
else if(strncmp(msg,"LIST",4)==0){
list(fd,datafd,msg);
}
else if(strncmp(msg,"RETR",4)==0){
retr(fd,datafd,msg);
}
else {
printf("input error\n");
continue;
}
}
}

int main(){
int fd;
struct sockaddr_in sock;
fd=socket(AF_INET,SOCK_STREAM,0);
bzero(&sock,sizeof(sock));
sock.sin_family=AF_INET;
sock.sin_port=htons(21);
sock.sin_addr.s_addr=inet_addr("127.0.0.1");
if(connect(fd,(struct sockaddr*)&sock,sizeof(sock))<0){
printf("%d",errno);
exit(0);
}
process(fd);
return 0;
}


