#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<stdio.h>
#include<dirent.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
#include<errno.h>

void sendres(int fd,char* p){
write(fd,p,4);
}

int login(int fd){
char user[30],pass[30],username[30],passwd[30];
FILE* fp=fopen("user.txt","r");
fgets(username,30,fp);
fgets(passwd,30,fp);
sendres(fd,"332");
read(fd,user,30);
sendres(fd,"331");
read(fd,pass,30);
int m=strlen(user);
int n=strlen(pass);
if(strncmp(pass,passwd,n)==0&&strncmp(user,username,m)==0) return 0;
else return 1;
}

int dataconn(){
int lfd,cfd;
struct sockaddr_in cli,ser;
lfd=socket(AF_INET,SOCK_STREAM,0);
bzero(&ser,sizeof(ser));
ser.sin_family=AF_INET;
ser.sin_port=htons(20);
ser.sin_addr.s_addr=htonl(INADDR_ANY);
bind(lfd,(struct sockaddr*)&ser,sizeof(ser));
listen(lfd,10);
int n=sizeof(cli);
cfd=accept(lfd,(struct sockaddr*)&cli,&n);
return cfd;
}

int list(int fd,int datafd,char cmd[]){
char buf[100],c[100];
int i=5,j=0;
while(cmd[i]!='\0'){
c[j++]=cmd[i++];
}
FILE* fp;
if(strncmp(c,"cli1.txt",8)==0){
fp=fopen("cli1.txt","r");
sendres(fd,"213");
}
else if(strncmp(c,"cli2.txt",8)==0){
fp=fopen("cli2.txt","r");
sendres(fd,"213");
}
else if(strncmp(c,"cli3.txt",8)==0){
fp=fopen("cli3.txt","r");
sendres(fd,"213");
}
else {
sendres(fd,"450");
return 0;
}
while(fgets(buf,100,fp)!=NULL){
int n=strlen(buf);
write(datafd,buf,sizeof(buf));
if(n==1) break;
memset(buf,0,100);
}
return 1;
}

int retr(int fd,int datafd,char cmd[]){
int j=5;
while(cmd[j]!='\0') j++;
DIR *p;
if(strncmp(cmd,"RETR ftpserverfile",j)==0){
p=opendir("ftpserverfile");
sendres(fd,"213");
}
else if(strncmp(cmd,"RETR ftpclientfile",j)==0){
p=opendir("ftpclientfile");
sendres(fd,"213");
}
else {
sendres(fd,"450");
return 0;
}
struct dirent* dir;
while((dir=readdir(p))!=NULL){
char buf[100];
sprintf(buf,"%ld:%s\n",dir->d_ino,dir->d_name);
write(datafd,buf,sizeof(buf));
}
char buf[100];
strcpy(buf,"END");
write(datafd,buf,sizeof(buf));
closedir(p);
return 1;
}

void process(int fd){
sendres(fd,"220");
if(login(fd)==0) {
sendres(fd,"226");
}
else{
sendres(fd,"530");
exit(0);
}
int datafd=dataconn();
sendres(fd,"225");
while(1){
char cmd[30];
int n=read(fd,cmd,30);
if(strncmp(cmd,"LIST",4)==0){
if(list(fd,datafd,cmd))
sendres(fd,"250");
else continue;
}
else if(strncmp(cmd,"RETR",4)==0){
if(retr(fd,datafd,cmd))
sendres(fd,"250");
else continue;
}
if(strncmp(cmd,"QUIT",4)==0){
sendres(fd,"221");
exit(0);
}
}
}

int main(){
int lfd,cfd;
pid_t pid;
struct sockaddr_in cli,ser;
lfd=socket(AF_INET,SOCK_STREAM,0);
bzero(&ser,sizeof(ser));
ser.sin_family=AF_INET;
ser.sin_port=htons(21);
ser.sin_addr.s_addr=htonl(INADDR_ANY);
bind(lfd,(struct sockaddr*)&ser,sizeof(ser));
listen(lfd,10);
while(1){
int n=sizeof(cli);
cfd=accept(lfd,(struct sockaddr*)&cli,&n);
if( (pid=fork()) ==0){
close(lfd);
process(cfd);
exit(0);
}
close(cfd);
}
}

